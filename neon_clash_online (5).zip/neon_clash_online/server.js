const http = require('http');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');
const ROOT = path.join(__dirname, 'public');
const server = http.createServer((req, res) => {
  const pathname = decodeURIComponent((req.url || '/').split('?')[0]);
  const file = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const full = path.resolve(ROOT, file);
  if (!full.startsWith(ROOT + path.sep) && full !== path.join(ROOT, 'index.html')) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(full, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    const ext = path.extname(full);
    const types = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'};
    res.writeHead(200, {'Content-Type': types[ext] || 'application/octet-stream', 'Cache-Control':'no-store'});
    res.end(data);
  });
});
const wss = new WebSocket.Server({ server });
const rooms = new Map();
const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function makeCode(){ let c; do { c=''; for(let i=0;i<5;i++) c+=alphabet[Math.floor(Math.random()*alphabet.length)]; } while(rooms.has(c)); return c; }
function send(ws, obj){ if(ws && ws.readyState===WebSocket.OPEN) ws.send(JSON.stringify(obj)); }
function roomBroadcast(room, obj, except){ for(const client of room.players) if(client && client!==except) send(client,obj); }
wss.on('connection', ws => {
  ws.roomCode=null; ws.player=-1;
  ws.on('message', raw => {
    let m; try { m=JSON.parse(raw.toString()); } catch { return; }
    if (ws.roomCode) {
      const room=rooms.get(ws.roomCode); if(!room) return;
      if(m.type==='start' && ws.player===0){ roomBroadcast(room,{type:'start'}); return; }
      if(m.type==='input' && m.input && typeof m.input==='object'){
        const clean={left:!!m.input.left,right:!!m.input.right,jump:!!m.input.jump};
        roomBroadcast(room,{type:'input',player:ws.player,input:clean},ws); return;
      }
      if(m.type==='action' && ['punch','kick','chargeStart','chargeEnd','heal'].includes(m.action)){
        roomBroadcast(room,{type:'action',player:ws.player,action:m.action},ws); return;
      }
      return;
    }
    if(m.type==='create'){
      const code=makeCode(), room={players:[ws,null]}; rooms.set(code,room);
      ws.roomCode=code;ws.player=0;send(ws,{type:'joined',code,player:0});return;
    }
    if(m.type==='join'){
      const code=String(m.code||'').toUpperCase().replace(/[^A-Z0-9]/g,''); const room=rooms.get(code);
      if(!room){send(ws,{type:'error',message:'その部屋は見つかりません。コードを確認してね。'});return;}
      if(room.players[1]){send(ws,{type:'error',message:'この部屋は満員です。'});return;}
      room.players[1]=ws;ws.roomCode=code;ws.player=1;
      send(ws,{type:'joined',code,player:1});roomBroadcast(room,{type:'peer',connected:true},ws);return;
    }
  });
  ws.on('close',()=>{
    if(!ws.roomCode)return;const room=rooms.get(ws.roomCode);if(!room)return;
    if(room.players[ws.player]===ws)room.players[ws.player]=null;
    roomBroadcast(room,{type:'peer',connected:false});
    if(!room.players[0]&&!room.players[1])rooms.delete(ws.roomCode);
  });
});
const PORT=process.env.PORT||3000;
server.listen(PORT,()=>console.log(`NEON CLASH online server listening on ${PORT}`));
